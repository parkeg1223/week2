#include "Header.h"

void func1(int page, int *num) {

	int i = 0, digit = 0, nTmp = page;

	while(nTmp != 0) {
		nTmp /= 10;
		digit++;
	}

	num[digit] = -1;

	while(digit >  0) {
		num[--digit] = page % 10;
		page /= 10;
	}
}
