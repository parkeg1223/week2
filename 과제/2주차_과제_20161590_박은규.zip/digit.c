#include "Header.h"

void func2(int *num, int *digit) {

	int i;
	for(i = 0; num[i] != -1; i++)
		digit[num[i]]++;
}
