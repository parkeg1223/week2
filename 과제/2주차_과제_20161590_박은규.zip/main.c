#include "Header.h"

int num[12] = { 0 };
int digit[10] = { 0 };

int main() {

	int i, j, k, n = 0;
	int *T;
	scanf("%d", &n);
	T = (int *)malloc(n * sizeof(int));
	for(i = 0; i < n; i++) {
		scanf("%d", &T[i]);
	}
	
	for(i = 0; i < n; i++) {
		for(j = 1; j <= T[i]; j++) {		
			func1(j, num);
			func2(num, digit);
		}

		for(j = 0; j < 10; j++)
			printf("%d ", digit[j]);
		printf("\n");

		memset(num, 0, 12 * sizeof(int));
		memset(digit, 0, 10 * sizeof(int));
	}
	
	free(T);
	return 0;	
}
