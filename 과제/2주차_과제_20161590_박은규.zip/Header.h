#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void func1(int page, int *num);
void func2(int *num, int *digit);
